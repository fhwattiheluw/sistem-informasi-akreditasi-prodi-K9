<footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © akresmart {{ date('Y') }}. develop by <a href="https://www.instagram.com/baku.kele">baku.kele</a> </span>
          </div>
        </footer>
