<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
<a href="/kriteria4/profil_tendik">
  <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
</a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.4 Sumber Daya Manusia</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>
             Profil Tendik
          </h4>

            <p class="card-description">K.4 Sumber Daya Manusia</p>
            <?php if($errors->any()): ?>
              <div>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li style="color: red;"><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
            <hr>
            <form action="<?php echo e(isset($item->id) ?  route('profil_tendik.update', ['id' => Crypt::encryptString($item->id)])  : route('profil_tendik.store')); ?>" method="post">
              <?php if(isset($item->id)): ?>
                <?php echo method_field('PUT'); ?>
              <?php endif; ?>
              <?php echo csrf_field(); ?>
              <div class="table-responsive">

              </div>

                  <table class="table table-striped table-bordered">
                  <tbody class="text-justify">
                   <tr>
  <td>ID Tendik</td>
  <td>
    <input type="text" class="form-control <?php $__errorArgs = ['id_tendik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_tendik" id="id_tendik" value="<?php echo e(isset($item->id_tendik) ? $item->id_tendik : old('id_tendik')); ?>" placeholder="ketik disini" <?php if(isset($item->id_tendik)): ?> readonly <?php endif; ?>>
    <?php $__errorArgs = ['id_tendik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </td>
</tr>
<tr>
  <td>Nama Lengkap</td>
  <td>
    <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" value="<?php echo e(isset($item->nama) ? $item->nama : old('nama')); ?>" placeholder="ketik disini">
    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </td>
</tr>
<tr>
  <td>Status</td>
  <td>
    <input type="text" class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status" value="<?php echo e(isset($item->status) ? $item->status : old('status')); ?>" placeholder="ketik disini">
    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </td>
</tr>
<tr>
  <td>Bidang Keahlian</td>
  <td>
    <input type="text" class="form-control <?php $__errorArgs = ['bidang_keahlian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bidang_keahlian" value="<?php echo e(isset($item->bidang_keahlian) ? $item->bidang_keahlian : old('bidang_keahlian')); ?>" placeholder="ketik disini">
    <?php $__errorArgs = ['bidang_keahlian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </td>
</tr>
<tr>
  <td>Pendidikan</td>
  <td>
    <div class="form-group row" style="margin: 0px; padding:0px;">
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pendidikan" id="slta" value="SLTA" <?php if(isset($item->pendidikan) && $item->pendidikan == 'SLTA'): ?> checked <?php endif; ?>> SLTA <i class="input-helper"></i>
          </label>
        </div>
      </div>
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pendidikan" id="diploma" value="Diploma" <?php if(isset($item->pendidikan) && $item->pendidikan == 'Diploma'): ?> checked <?php endif; ?>> Diploma <i class="input-helper"></i>
          </label>
        </div>
      </div>
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pendidikan" id="s1" value="S1" <?php if(isset($item->pendidikan) && $item->pendidikan == 'S1'): ?> checked <?php endif; ?>> S1 <i class="input-helper"></i>
          </label>
        </div>
      </div>
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pendidikan" id="s2" value="S2" <?php if(isset($item->pendidikan) && $item->pendidikan == 'S2'): ?> checked <?php endif; ?>> S2 <i class="input-helper"></i>
          </label>
        </div>
      </div>
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pendidikan" id="s3" value="S3" <?php if(isset($item->pendidikan) && $item->pendidikan == 'S3'): ?> checked <?php endif; ?>> S3 <i class="input-helper"></i>
          </label>
        </div>
      </div>
    </div>
    <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </td>
</tr>
<tr>
  <td>Unit Kerja</td>
  <td>
    <div class="form-group row" style="margin: 0px; padding:0px;">
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['unit_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit_kerja" id="PS" value="PS" <?php if(isset($item->unit_kerja) && $item->unit_kerja == 'PS'): ?> checked <?php endif; ?>> PS <i class="input-helper"></i>
          </label>
        </div>
      </div>
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['unit_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit_kerja" id="UPPS" value="UPPS" <?php if(isset($item->unit_kerja) && $item->unit_kerja == 'UPPS'): ?> checked <?php endif; ?>> UPPS <i class="input-helper"></i>
          </label>
        </div>
      </div>
      <div class="col">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['unit_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit_kerja" id="PT" value="PT" <?php if(isset($item->unit_kerja) && $item->unit_kerja == 'PT'): ?> checked <?php endif; ?>> PT <i class="input-helper"></i>
          </label>
        </div>
      </div>
    </div>
    <?php $__errorArgs = ['unit_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </td>
</tr>


                    <tr>
                      <td >Bukti/Tautan</td>

                      <td><input type="text" class="form-control" name="tautan" value="<?php echo e(isset($item->tautan) ? $item->tautan : old('tautan')); ?>" placeholder="ketik disini"></td>
                    </tr>
                    <tr>
                      <td>
                        <?php if(Request::segment(3) === 'create'): ?>
                          <button type="submit" class="btn btn-primary mr-2" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';"> Tambah data</button>
                        <?php elseif(Request::segment(4) === 'edit'): ?>
                          <button type="submit" class="btn btn-primary mr-2" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';"> Update data</button>
                        <?php endif; ?>
                      </td>
                    </tr>

                  </tbody>

                </table>

            </form>
          </div>
              </div>
            </div>
          </div>
          <!-- last row starts here -->

        </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c4/profil_tendik/form.blade.php ENDPATH**/ ?>