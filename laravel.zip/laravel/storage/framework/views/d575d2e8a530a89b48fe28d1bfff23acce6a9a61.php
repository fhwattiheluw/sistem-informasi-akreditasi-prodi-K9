<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($details['subject']); ?></title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['email']); ?></p>
    <p><?php echo e($details['body']); ?></p>
    <p>Silahkan akses website di alamat : <?php echo e(route('login')); ?></p>
</body>
</html>
<?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/email/sendMail.blade.php ENDPATH**/ ?>