<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <?php if(auth()->user()->role == 'admin prodi'): ?>
      <a href="/kriteria5/prasarana_pendidikan/create">
        <button class="btn btn-outline-primary mb-2 mb-md-0 mr-2"> Tambah data </button>
      </a>
      <?php endif; ?>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif LED</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.5 Keuangan, Sarana, dan Prasarana</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Tabel Data Prasarana Pendidikan</h5>
          <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
          <?php endif; ?>
          <?php if(session('info')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('info')); ?> Silakan <a href="/dashboard">klik disini.</a>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
          <?php endif; ?>
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
              <thead class="text-center">
                <tr>
                  <th rowspan="2">Jenis Prasarana</th>
                  <th rowspan="2">Jumlah Unit</th>
                  <th rowspan="2">Luas (m2)</th>
                  <th colspan="2">Kepemilikan*</th>
                  <th colspan="2">Kondisi</th>
                  <th rowspan="2">Penggunaan (Jam/minggu)</th>
                  <th rowspan="2">Bukti/Tautan</th>
                  <?php if(auth()->user()->role == 'admin prodi'): ?>
                  <th rowspan="2">Aksi</th>
                  <?php endif; ?>
                </tr>
                <tr>
                  <th>SD</th>
                  <th>SW</th>
                  <th>Terawat</th>
                  <th>Tidak Terawat</th>
                </tr>
              </thead>
              <tbody class="text-center">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($item->jenis_prasarana); ?></td>
                  <td><?php echo e($item->jumlah_unit); ?></td>
                  <td><?php echo e($item->luas); ?></td>
                  <td><?php if($item->kepemilikan == 'SD'): ?> V <?php endif; ?></td>
                  <td><?php if($item->kepemilikan == 'SW'): ?> V <?php endif; ?></td>
                  <td><?php if($item->kondisi == 'terawat'): ?> V <?php endif; ?></td>
                  <td><?php if($item->kondisi == 'tidak terawat'): ?> V <?php endif; ?></td>
                  <td><?php echo e($item->penggunaan); ?></td>
                  <td>
                      <a href="<?php echo e($item->tautan); ?>">
                        <button type="button" class="btn btn-outline-success btn-sm"><i class="mdi mdi-link"></i></button>
                      </a>
                  </td>
                  <?php if(auth()->user()->role == 'admin prodi'): ?>
                  <td>
                    <a href="/kriteria5/prasarana_pendidikan/<?php echo e($item->id); ?>/edit">
                      <button type="button" class="btn btn-outline-primary btn-sm"><i class="mdi mdi-table-edit" ></i></button>
                    </a>
                    <a type="button" href="/kriteria5/prasarana_pendidikan/<?php echo e($item->id); ?>/delete" onclick="confirm('Apakah anda yakin untuk menghapus data ini ?')" class="btn btn-outline-danger btn-sm"><i class="mdi mdi-delete icon" ></i> </a>

                  </td>
                  <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>

            </table>
          </div>

        </div>
      </div>
    </div>
  </div>
  <!-- last row starts here -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c5/prasarana_pendidikan/index.blade.php ENDPATH**/ ?>