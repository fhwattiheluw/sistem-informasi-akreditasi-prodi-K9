<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="/kriteria4/kegiatan_mengajar_dosen_tetap">
        <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
      </a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.4 Sumber Daya Manusia</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>

            Beban Kerja Dosen DTPS
          </h4>

          <p class="card-description">K.4 Sumber Daya Manusia</p>
          <?php if($errors->any()): ?>
              <div>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li style="color: red;"><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
          <hr>
          <form action="<?php echo e(isset($item->id) ?  route('kegiatan_mengajar_dosen_tetap.update', ['id' => Crypt::encryptString($item->id)])  : route('kegiatan_mengajar_dosen_tetap.store')); ?>" method="post">
            <?php if(isset($item->id)): ?>
              <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <?php echo csrf_field(); ?>

            <table class="table">
              <tr>
    <td><label class="col-form-label">Semester</label></td>
    <td>
        <div class="form-check">
            <label class="form-check-label">
                <input type="radio" class="form-check-input" name="semester" value="Gasal"  <?php if(isset($item->semester) && $item->semester == 'Gasal'): ?> checked <?php endif; ?>> Gasal <i class="input-helper"></i>
            </label>
        </div>
        <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
    <td>
        <div class="form-check">
            <label class="form-check-label">
                <input type="radio" class="form-check-input" name="semester" value="Genap" <?php if(isset($item->semester) && $item->semester == 'Genap'): ?> checked <?php endif; ?>> Genap <i class="input-helper"></i>
            </label>
        </div>
        <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</tr>
<tr>
    <td><label class="col-form-label">Nama Lengkap</label></td>
    <td colspan="2">
        <select class="form-control <?php $__errorArgs = ['dosen_ketua_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dosen_ketua_id">
            <option value="">Pilih</option>
            <?php $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($dosen->nidn_nidk); ?>"
                    <?php if(old('dosen_ketua_id', isset($item->dosen_ketua_id) ? $item->dosen_ketua_id : '') == $dosen->nidn_nidk): ?> selected <?php endif; ?>>
                    <?php echo e($dosen->nidn_nidk); ?> | <?php echo e($dosen->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['dosen_ketua_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</tr>
<tr>
    <td><label class="col-form-label">Jumlah Kelas</label></td>
    <td colspan="2">
        <input type="text" name="jumlah_kelas" value="<?php echo e(old('jumlah_kelas', isset($item->jumlah_kelas) ? $item->jumlah_kelas : '')); ?>" class="form-control <?php $__errorArgs = ['jumlah_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Belum di isi">
        <?php $__errorArgs = ['jumlah_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</tr>
<tr>
    <td><label class="col-form-label">Mata Kuliah</label></td>
    <td colspan="2">
        <select name="kode_mk" id="kode_mk" class="form-control <?php $__errorArgs = ['kode_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php if(isset($item->kode_mk)): ?>
                <option value="<?php echo e($item->kode_mk); ?>"><?php echo e($item->kode_mk); ?> | <?php echo e($item->dosen->nama); ?></option>
            <?php else: ?>
                <option value="" disabled>Pilih Mata Kuliah</option>
                <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($mk->kode_mk); ?>">
                        <?php echo e($mk->kode_mk); ?> | <?php echo e($mk->nama); ?> | <?php echo e($mk->sks); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <?php $__errorArgs = ['kode_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</tr>
<tr>
    <td><label class="col-form-label">Jumlah Pertemuan yang Direncanakan</label></td>
    <td colspan="2">
        <input type="text" name="jum_pertemuan_rencana" value="<?php echo e(old('jum_pertemuan_rencana', isset($item->jum_pertemuan_rencana) ? $item->jum_pertemuan_rencana : '')); ?>" class="form-control <?php $__errorArgs = ['jum_pertemuan_rencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Belum di isi">
        <?php $__errorArgs = ['jum_pertemuan_rencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</tr>
<tr>
    <td><label class="col-form-label">Jumlah Pertemuan yang Dilaksanakan</label></td>
    <td colspan="2">
        <input type="text" name="jum_pertemuan_terlaksana" value="<?php echo e(old('jum_pertemuan_terlaksana', isset($item->jum_pertemuan_terlaksana) ? $item->jum_pertemuan_terlaksana : '')); ?>" class="form-control <?php $__errorArgs = ['jum_pertemuan_terlaksana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Belum di isi">
        <?php $__errorArgs = ['jum_pertemuan_terlaksana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</tr>
<tr>
    <td><label class="col-form-label">Bukti/Tautan</label></td>
    <td colspan="2">
        <input type="text" name="tautan" value="<?php echo e(old('tautan', isset($item->tautan) ? $item->tautan : '')); ?>" class="form-control <?php $__errorArgs = ['tautan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Belum di isi">
        <?php $__errorArgs = ['tautan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</tr>

            </table>
            <?php if(Request::segment(3) === 'create'): ?>
            <button type="submit" class="btn btn-primary mr-2" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';"> Tambah data</button>
            <?php elseif(Request::segment(4) === 'edit'): ?>
            <button type="submit" class="btn btn-primary mr-2" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';"> Update data</button>
            <?php endif; ?>

          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- last row starts here -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c4/kegiatan_mengajar_dosen_tetap/form.blade.php ENDPATH**/ ?>