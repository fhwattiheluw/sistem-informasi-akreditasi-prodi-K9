<?php echo e($slot); ?>

<?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>