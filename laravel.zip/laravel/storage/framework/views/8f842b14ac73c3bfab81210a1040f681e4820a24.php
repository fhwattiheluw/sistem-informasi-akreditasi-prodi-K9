<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="/kriteria5/pemerolehan_dana">
        <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
      </a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.5 Keuangan, Sarana, dan Prasarana</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <form class="card forms-sample" action="<?php echo e(isset($item->id) ?  route('pemerolehan_dana.update', ['id' => Crypt::encryptString($item->id)])  : route('pemerolehan_dana.store')); ?>" method="post">
        <?php if(isset($item->id)): ?>
          <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
          <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>

            Pemerolehan Dana
          </h4>

          <p class="card-description">K.5 Investsi sarana pendidikan</p>
          <?php if($errors->any()): ?>
              <div>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li style="color: red;"><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
          <hr>

          <div class="form-group row">
    <label class="col-sm-3 col-form-label">Sumber Dana</label>
    <div class="col-sm-9">
        <select class="form-control <?php $__errorArgs = ['sumber_dana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="sumber_dana">
            <option value="">Pilih</option>
            <option value="Perguruan tinggi sendiri" <?php if(old('sumber_dana', isset($item->sumber_dana) ? $item->sumber_dana : '') == "Perguruan tinggi sendiri"): ?> selected <?php endif; ?>>Perguruan tinggi sendiri</option>
            <option value="Yayasan" <?php if(old('sumber_dana', isset($item->sumber_dana) ? $item->sumber_dana : '') == "Yayasan"): ?> selected <?php endif; ?>>Yayasan</option>
            <option value="Kementerian" <?php if(old('sumber_dana', isset($item->sumber_dana) ? $item->sumber_dana : '') == "Kementerian"): ?> selected <?php endif; ?>>Kementerian</option>
            <option value="Lembaga tertentu DN/LN" <?php if(old('sumber_dana', isset($item->sumber_dana) ? $item->sumber_dana : '') == "Lembaga tertentu DN/LN"): ?> selected <?php endif; ?>>Lembaga tertentu DN/LN</option>
            <option value="Sumber lain" <?php if(old('sumber_dana', isset($item->sumber_dana) ? $item->sumber_dana : '') == "Sumber lain"): ?> selected <?php endif; ?>>Sumber lain</option>
        </select>
        <?php $__errorArgs = ['sumber_dana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">Jenis Dana</label>
    <div class="col-sm-9">
        <input type="text" name="jenis_dana" value="<?php echo e(isset($item->jenis_dana) ? $item->jenis_dana : old('jenis_dana')); ?>" class="form-control <?php $__errorArgs = ['jenis_dana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['jenis_dana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">TS-2 (<?php echo e(date('Y') - 2); ?>)</label>
    <div class="col-sm-9">
        <input type="text" name="jumlah_ts2" value="<?php echo e(isset($item->jumlah_ts2) ? $item->jumlah_ts2 : old('jumlah_ts2')); ?>" id="nilai2" class="form-control <?php $__errorArgs = ['jumlah_ts2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['jumlah_ts2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">TS-1 (<?php echo e(date('Y') - 1); ?>)</label>
    <div class="col-sm-9">
        <input type="text" name="jumlah_ts1" id="nilai1" value="<?php echo e(isset($item->jumlah_ts1) ? $item->jumlah_ts1 : old('jumlah_ts1')); ?>" class="form-control <?php $__errorArgs = ['jumlah_ts1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['jumlah_ts1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">TS (<?php echo e(date('Y')); ?>)</label>
    <div class="col-sm-9">
        <input type="text" name="jumlah_ts" id="nilai" value="<?php echo e(isset($item->jumlah_ts) ? $item->jumlah_ts : old('jumlah_ts')); ?>" class="form-control <?php $__errorArgs = ['jumlah_ts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['jumlah_ts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Tautan</label>
            <div class="col-sm-9">
              <input type="text" name="tautan" value="<?php echo e(isset($item->tautan) ? $item->tautan : old('tautan')); ?>" class="form-control" placeholder="Ketik disini">
            </div>
          </div>


          </div>

          <div class="card-footer">
            <button class="btn btn-primary" type="submit" name="button" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';">
              <?php if(Request::segment(3) === 'create'): ?>
              Tambah data
              <?php elseif(Request::segment(4) === 'edit'): ?>
              Update data
              <?php endif; ?>
            </button>
          </div>
        </form>
      </div>
    </div>
    <!-- last row starts here -->

  </div>
  <script>
    document.getElementById('nilai2').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
    document.getElementById('nilai1').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
    document.getElementById('nilai').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
</script>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c5/pemerolehan_dana/form.blade.php ENDPATH**/ ?>