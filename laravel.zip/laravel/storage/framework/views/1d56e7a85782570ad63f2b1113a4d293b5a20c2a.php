<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="/kriteria5/sarana_pendidikan">
        <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
      </a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.5 Sarana Pendidikan</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <div class="card">
          
          <form action="<?php echo e(isset($item->id) ?  route('sarana_pendidikan.update', ['id' => Crypt::encryptString($item->id)])  : route('sarana_pendidikan.store')); ?>" method="post">
            <?php if(isset($item->id)): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="card-body">
              <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>
            Sarana Pendidikan
          </h4>

          <p class="card-description">K.5 Sarana Pendidikan</p>
          <?php if($errors->any()): ?>
          <div>
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li style="color: red;"><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <?php endif; ?>
          <hr>

              <div class="form-group row">
  <label class="col-sm-3 col-form-label">Jenis Sarana</label>
  <div class="col-sm-9">
    <input type="text" name="jenis_sarana" value="<?php echo e(isset($item->jenis_sarana) ? $item->jenis_sarana : old('jenis_sarana')); ?>" class="form-control <?php $__errorArgs = ['jenis_sarana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['jenis_sarana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Jumlah Unit</label>
  <div class="col-sm-9">
    <input type="number" name="jumlah_unit" value="<?php echo e(isset($item->jumlah_unit) ? $item->jumlah_unit : old('jumlah_unit')); ?>" class="form-control <?php $__errorArgs = ['jumlah_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['jumlah_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row" style="margin: 0px; padding:0px;">
  <label class="col-sm-3 col-form-label">Kualitas</label>
  <div class="col-sm-9">
    <div class="form-group <?php $__errorArgs = ['kualitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
      <div class="form-check">
        <label class="form-check-label">
          <input type="radio" class="form-check-input" id="baik" name="kualitas" value="Baik" <?php if(isset($item->kualitas) && $item->kualitas == 'Baik'): ?> checked <?php endif; ?>>
          Baik<i class="input-helper"></i>
        </label>
      </div>
      <div class="form-check">
        <label class="form-check-label">
          <input type="radio" class="form-check-input" id="kurang_baik" name="kualitas" value="Kurang Baik" <?php if(isset($item->kualitas) && $item->kualitas == 'Kurang Baik'): ?> checked <?php endif; ?>>
          Kurang Baik<i class="input-helper"></i>
        </label>
      </div>
      <div class="form-check">
        <label class="form-check-label">
          <input type="radio" class="form-check-input" id="tidak_baik" name="kualitas" value="Tidak Baik" <?php if(isset($item->kualitas) && $item->kualitas == 'Tidak Baik'): ?> checked <?php endif; ?>>
          Tidak Baik
        </label>
      </div>
    </div>
    <?php $__errorArgs = ['kualitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Kondisi</label>
  <div class="col-sm-9">
    <select class="form-control <?php $__errorArgs = ['kondisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kondisi">
      <option value="">--Pilih--</option>
      <option value="terawat" <?php if(isset($item->kondisi) && $item->kondisi == 'terawat'): ?> selected <?php endif; ?>>Terawat</option>
      <option value="tidak terawat" <?php if(isset($item->kondisi) && $item->kondisi == 'tidak terawat'): ?> selected <?php endif; ?>>Tidak Terawat</option>
    </select>
    <?php $__errorArgs = ['kondisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Unit Pengelola (PS, UPPS, PT)</label>
  <div class="col-sm-9">
    <select class="form-control <?php $__errorArgs = ['unit_pengelola'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit_pengelola">
      <option value="">--Pilih--</option>
      <option value="PS" <?php if(isset($item->unit_pengelola) && $item->unit_pengelola == 'PS'): ?> selected <?php endif; ?>>PS</option>
      <option value="UPPS" <?php if(isset($item->unit_pengelola) && $item->unit_pengelola == 'UPPS'): ?> selected <?php endif; ?>>UPPS</option>
      <option value="PT" <?php if(isset($item->unit_pengelola) && $item->unit_pengelola == 'PT'): ?> selected <?php endif; ?>>PT</option>
    </select>
    <?php $__errorArgs = ['unit_pengelola'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Tautan</label>
            <div class="col-sm-9">
              <input class="form-control" type="text" name="tautan" value="<?php echo e(isset($item->tautan) ? $item->tautan : old('tautan')); ?>" placeholder="Tautan di sini">
            </div>
          </div>
        </div>

        <div class="card-footer">
          <button class="btn btn-primary" type="submit" name="button" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Update data
            <?php endif; ?>
          </button>
        </div>
      </form>
  </div>
</div>
</div>
<!-- last row starts here -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c5/sarana_pendidikan/form.blade.php ENDPATH**/ ?>