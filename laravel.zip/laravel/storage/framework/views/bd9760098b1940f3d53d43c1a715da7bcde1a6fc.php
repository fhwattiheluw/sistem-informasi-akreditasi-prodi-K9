<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="/kriteria7/pelibatan_mahasiswa_dalam_penelitian">
        <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
      </a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.7 Pelibatan Mahasiswa dalam Penelitian</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <form class="card forms-sample" action="<?php echo e(isset($item->id) ?  route('pelibatan_mahasiswa_dalam_penelitian.update', ['id' => Crypt::encryptString($item->id)])  : route('pelibatan_mahasiswa_dalam_penelitian.store')); ?>" method="post">
        <?php if(isset($item->id)): ?>
        <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
          <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>

            Data Pelibatan Mahasiswa dalam Penelitian
          </h4>

          <p class="card-description">K.7 Pelibatan Mahasiswa dalam Penelitian</p>
          <?php if($errors->any()): ?>
          <div>
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li style="color: red;"><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <?php endif; ?>
          <hr>

          <div class="form-group row">
  <label class="col-sm-3 col-form-label">Tahun Akademik</label>
  <div class="col-sm-9">
    <input type="number" name="tahun_akademik" value="<?php echo e(old('tahun_akademik', isset($item->tahun_akademik) ? $item->tahun_akademik : '')); ?>" class="form-control <?php $__errorArgs = ['tahun_akademik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['tahun_akademik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Judul</label>
  <div class="col-sm-9">
    <input type="text" name="judul" value="<?php echo e(old('judul', isset($item->judul) ? $item->judul : '')); ?>" class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Ketua Tim</label>
  <div class="col-sm-9">
    <select class="form-control <?php $__errorArgs = ['dosen_ketua_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dosen_ketua_id">
      <option value="">Pilih</option>
      <?php $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($dosen->nidn_nidk); ?>"
          <?php if(old('dosen_ketua_id', isset($item->dosen_ketua_id) ? $item->dosen_ketua_id : '') == $dosen->nidn_nidk): ?> selected <?php endif; ?>>
          <?php echo e($dosen->nidn_nidk); ?> | <?php echo e($dosen->nama); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['dosen_ketua_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Kepakaran ketua</label>
  <div class="col-sm-9">
    <input type="text" name="kepakaran_ketua" value="<?php echo e(old('kepakaran_ketua', isset($item->kepakaran_ketua) ? $item->kepakaran_ketua : '')); ?>" class="form-control <?php $__errorArgs = ['kepakaran_ketua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['kepakaran_ketua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Dosen Anggota</label>
  <div class="col-sm-9">
    <select class="form-control <?php $__errorArgs = ['dosen_anggota_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dosen_anggota_id">
      <option value="">Pilih</option>
      <?php $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($dosen->nidn_nidk); ?>"
          <?php if(old('dosen_anggota_id', isset($item->dosen_anggota_id) ? $item->dosen_anggota_id : '') == $dosen->nidn_nidk): ?> selected <?php endif; ?>>
          <?php echo e($dosen->nidn_nidk); ?> | <?php echo e($dosen->nama); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['dosen_anggota_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">Mahasiswa</label>
  <div class="col-sm-9">
    <input type="text" name="mahasiswa" value="<?php echo e(old('mahasiswa', isset($item->mahasiswa) ? $item->mahasiswa : '')); ?>" class="form-control <?php $__errorArgs = ['mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>


              <div class="form-group row">
                <label class="col-sm-3 col-form-label">Bukti/Tautan</label>
                <div class="col-sm-9">
                  <input type="text" name="tautan" value="<?php echo e(isset($item->tautan) ? $item->tautan : old('tautan')); ?>" class="form-control" placeholder="Ketik disini">
                </div>
              </div>
            </div>

              <div class="card-footer">
                <button class="btn btn-primary" type="submit" name="button" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';">
                  <?php if(Request::segment(3) === 'create'): ?>
                  Tambah data
                  <?php elseif(Request::segment(4) === 'edit'): ?>
                  Update data
                  <?php endif; ?>
                </button>
              </div>
            </form>
          </div>
        </div>
        <!-- last row starts here -->

      </div>

      <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c7/pelibatan_mahasiswa_dalam_penelitian/form.blade.php ENDPATH**/ ?>