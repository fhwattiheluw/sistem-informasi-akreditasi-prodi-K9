<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="/kriteria6/mata_kuliah_cpl_dan_perangkat_pembelajaran/">
        <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
      </a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.6 Mata Kuliah, CPL, dan Perangkat Pembelajaran</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <form class="card forms-sample" action="<?php echo e(isset($item->id) ?  route('mata_kuliah_cpl_dan_perangkat_pembelajaran.update', ['id' => Crypt::encryptString($item->id)])  : route('mata_kuliah_cpl_dan_perangkat_pembelajaran.store')); ?>" method="post">
        <?php if(isset($item->id)): ?>
          <?php echo method_field('PUT'); ?>
        <?php endif; ?>  
        <?php echo csrf_field(); ?>
        <div class="card-body">
          <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>

            Mata Kuliah
          </h4>

          <p class="card-description">K.6 Mata Kuliah, CPL, dan Perangkat Pembelajaran</p>
          <?php if($errors->any()): ?>
              <div>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li style="color: red;"><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
          <hr>

          <div class="form-group row">
    <label class="col-sm-3 col-form-label">Semester</label>
    <div class="col-sm-9">
        <select class="form-control <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="semester">
            <option value="">Pilih</option>
            <?php for($a = 1; $a <= 8; $a++): ?>
                <option value="<?php echo e($a); ?>" 
                  <?php if(old('semester', isset($item->semester) ? $item->semester : '') == $a): ?> selected <?php endif; ?>>
                  <?php echo e($a); ?></option>
            <?php endfor; ?>
        </select>
        <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">Kode Matakuliah</label>
    <div class="col-sm-9">
        <input type="text" name="kode_mk" value="<?php echo e(isset($item->kode_mk) ? $item->kode_mk : old('kode_mk')); ?>" class="form-control <?php $__errorArgs = ['kode_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['kode_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">Nama Matakuliah</label>
    <div class="col-sm-9">
        <input type="text" name="nama" value="<?php echo e(isset($item->nama) ? $item->nama : old('nama')); ?>" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">SKS</label>
    <div class="col-sm-9">
        <input type="number" name="sks" value="<?php echo e(isset($item->sks) ? $item->sks : old('sks')); ?>" class="form-control <?php $__errorArgs = ['sks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['sks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">Jenis Matakuliah</label>
    <div class="col-sm-9">
        <select class="form-control <?php $__errorArgs = ['jenis_matakuliah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jenis_matakuliah">
            <option value="">Pilih</option>
            <option value="teori" 
              <?php if(old('jenis_matakuliah', isset($item->jenis_matakuliah) ? $item->jenis_matakuliah : '') == "teori"): ?> selected <?php endif; ?>>
              Teori</option>
            <option value="praktikum" 
              <?php if(old('jenis_matakuliah', isset($item->jenis_matakuliah) ? $item->jenis_matakuliah : '') == "praktikum"): ?> selected <?php endif; ?>>
              Praktikum</option>
            <option value="praktik"
              <?php if(old('jenis_matakuliah', isset($item->jenis_matakuliah) ? $item->jenis_matakuliah : '') == "praktik"): ?> selected <?php endif; ?>>
              Praktik</option>              
        </select>
        <?php $__errorArgs = ['jenis_matakuliah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">Unit Penyelenggara</label>
    <div class="col-sm-9">
        <select class="form-control <?php $__errorArgs = ['unit_penyelenggara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit_penyelenggara">
            <option value="">Pilih</option>
            <option value="pt" 
              <?php if(old('unit_penyelenggara', isset($item->unit_penyelenggara) ? $item->unit_penyelenggara : '') == "pt"): ?> selected <?php endif; ?>>
              PT</option>
            <option value="upps" 
              <?php if(old('unit_penyelenggara', isset($item->unit_penyelenggara) ? $item->unit_penyelenggara : '') == "upps"): ?> selected <?php endif; ?>>
              UPPS</option>
            <option value="ps"
              <?php if(old('unit_penyelenggara', isset($item->unit_penyelenggara) ? $item->unit_penyelenggara : '') == "ps"): ?> selected <?php endif; ?>>
              PS</option>              
        </select>
        <?php $__errorArgs = ['unit_penyelenggara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">Kesesuaian CPL</label>
    <div class="col-sm-9">
        <div class="form-check">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['kesesuaian_cpl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kesesuaian_cpl" id="kesesuaian_cpl_ya" value="ya" 
                  <?php echo e((isset($item->kesesuaian_cpl) && $item->kesesuaian_cpl == 'ya') ? 'checked' : (old('kesesuaian_cpl') == 'ya' ? 'checked' : '')); ?>>
            <label class="form-check-label" for="kesesuaian_cpl_ya">Ya</label>
        </div>
        <div class="form-check">
            <input type="radio" class="form-check-input <?php $__errorArgs = ['kesesuaian_cpl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kesesuaian_cpl" id="kesesuaian_cpl_tidak" value="tidak" 
                  <?php echo e((isset($item->kesesuaian_cpl) && $item->kesesuaian_cpl == 'tidak') ? 'checked' : (old('kesesuaian_cpl') == 'tidak' ? 'checked' : '')); ?>>
            <label class="form-check-label" for="kesesuaian_cpl_tidak">Tidak</label>
        </div>
        <?php $__errorArgs = ['kesesuaian_cpl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-3 col-form-label">Perangkat Pembelajaran</label>
    <div class="col-sm-9">
        <input type="text" name="perangkat_pembelajaran" value="<?php echo e(isset($item->perangkat_pembelajaran) ? $item->perangkat_pembelajaran : old('perangkat_pembelajaran')); ?>" class="form-control <?php $__errorArgs = ['perangkat_pembelajaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
        <?php $__errorArgs = ['perangkat_pembelajaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Tautan</label>
            <div class="col-sm-9">
              <input type="text" name="tautan" value="<?php echo e(isset($item->tautan) ? $item->tautan : old('tautan')); ?>" class="form-control" placeholder="Ketik disini">
            </div>
          </div>


          </div>

          <div class="card-footer">
            <button class="btn btn-primary" type="submit" name="button">
              <?php if(Request::segment(3) === 'create'): ?>
              Tambah data
              <?php elseif(Request::segment(4) === 'edit'): ?>
              Update data
              <?php endif; ?>
            </button>
          </div>
        </form>
      </div>
    </div>
    <!-- last row starts here -->

  </div>
  <script>
    document.getElementById('nilai2').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
    document.getElementById('nilai1').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
    document.getElementById('nilai').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
</script>

  <?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c6/mata_kuliah_cpl_dan_perangkat_pembelajaran/form.blade.php ENDPATH**/ ?>