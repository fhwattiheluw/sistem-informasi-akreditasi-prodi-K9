<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="/repository/semua" class="btn btn-outline-primary">Manajemen Repository</a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Repository</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">Semua file dokumen akreditasi program studi</p>
        </a>
      </div>
    </div>
  </div>
  <!-- Tambahkan form filter tahun di sini -->
  <div class="row mb-3">
    <div class="col">
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('dokumen.index')); ?>" method="GET">
            <div class="form-group">
              <label for="kriteria">Filter Kriteria:</label>
              <select class="form-control" id="kriteria" name="kriteria">
                <?php for($i = 2; $i <= 9; $i++): ?>
                  <option value="<?php echo e($i); ?>" <?php echo e(request('kriteria') == $i ? 'selected' : ''); ?>>Kriteria <?php echo e($i); ?></option>
                <?php endfor; ?>
              </select>
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Semua dokumen</h5>
          <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('success')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <?php echo e(session('error')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Nama File</th>
                  <th>Nama Repository</th>
                  <th>Kriteria</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $repository; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $repo->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <?php if(strlen($doc->nama_dokumen) > 20): ?>
                      <div class="text-wrap"><?php echo e($doc->nama_dokumen); ?></div>
                    <?php else: ?>
                      <?php echo e($doc->nama_dokumen); ?>

                    <?php endif; ?>
                  </td>
                  <td>
                     <?php if(strlen($doc->nama_dokumen) > 20): ?> 
                     <div class="text-wrap">
                      <a href="/repository/show/<?php echo e($repo->id); ?>"><i class="fa fa-folder-open"></i><?php echo e($repo->nama_repository); ?></a>
                    </div>
                    <?php else: ?>
                    <a href="/repository/show/<?php echo e($repo->id); ?>"><i class="fa fa-folder-open"></i><?php echo e($repo->nama_repository); ?></a>
                      <?php endif; ?>
                  </td>
                  <td>Kriteria <?php echo e($repo->kriteria); ?></td>
                  <td>
                    <a href="#" onclick="openPopupDokumen('<?php echo e(url($doc->path)); ?>')" class="btn btn-primary btn-xs" title="Melihat Dokumen"><i class="fa fa-eye"></i></a>
                    <button class="btn btn-warning btn-xs" title="Edit" onclick="window.location.href='<?php echo e(route('dokumen.edit', $doc->id)); ?>'"><i class="fa fa-edit"></i></button>
                    <a href="<?php echo e(route('dokumen.delete', $doc->id)); ?>" class="btn btn-danger btn-xs" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus dokumen <?php echo e($doc->nama_dokumen); ?>?')"><i class="fa fa-trash"></i></a>
                    <button onclick="navigator.clipboard.writeText('<?php echo e(url($doc->path)); ?>'); alert('Tautan telah disalin ke papan klip.');" class="btn btn-info btn-xs" target="_blank"><i class="fa fa-link"></i></button>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Lebih banyak baris dapat ditambahkan di sini -->
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- last row starts here -->

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<!-- Tambahkan di dalam <head> atau sebelum penutup </body> -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Tempatkan skrip JS yang relevan di sini -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('.table').DataTable();
});

function openPopupDokumen(url) {
    var width = 500; // Width of the popup window
    var height = 600; // Height of the popup window
    var leftPosition = (screen.width - width) / 2;
    var topPosition = (screen.height - height) / 2;
    var popupOptions = 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=' + width + ', height=' + height + ', top=' + topPosition + ', left=' + leftPosition;

    window.open(url, 'Popup', popupOptions);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/dokumen/semua_dokumen.blade.php ENDPATH**/ ?>