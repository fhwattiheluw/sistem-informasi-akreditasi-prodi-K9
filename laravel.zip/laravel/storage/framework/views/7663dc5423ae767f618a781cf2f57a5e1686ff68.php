<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <!-- <button class="btn btn-primary mb-2 mb-md-0 mr-2"> Tambah data </button> -->
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">C.2 Tata Pamong, Tata Kelola, dan Kerjasama</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <form class="card" <?php if($bidang == "bidang%20pendidikan"): ?>
      action="<?php echo e(isset($item->id) ?  route('bidang_pendidikan.update', ['id' => Crypt::encryptString($item->id)])  : route('bidang_pendidikan.store')); ?>"
      <?php elseif($bidang == "bidang%20penelitian"): ?>
      action="<?php echo e(isset($item->id) ?  route('bidang_penelitian.update', ['id' => Crypt::encryptString($item->id)])  : route('bidang_penelitian.store')); ?>"
      <?php elseif($bidang == "bidang%20pkm"): ?>
      action="<?php echo e(isset($item->id) ?  route('bidang_pkm.update', ['id' => Crypt::encryptString($item->id)])  : route('bidang_pkm.store')); ?>"
      <?php elseif($bidang == "Bidang%20Pengembangan%20Kelembagaan"): ?>
      action="<?php echo e(isset($item->id) ?  route('bidang_pengembangan_kelembagaan.update', ['id' => Crypt::encryptString($item->id)])  : route('bidang_pengembangan_kelembagaan.store')); ?>"

      <?php endif; ?>
      method="post">
      <?php if(isset($item->id)): ?>
      <?php echo method_field('PUT'); ?>
      <?php endif; ?>

      <?php echo csrf_field(); ?>
      <div class="card-body">
        <h4 class="card-title">
          <?php if(Request::segment(3) == 'create'): ?>
          Tambah data
          <?php elseif(Request::segment(4) == 'edit'): ?>
          Edit data
          <?php endif; ?>
        <?php echo e($bidang); ?></h4>

        <p class="card-description">Data Kerja Sama </p> 
        <hr>

        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Nama Lembaga Mitra</label>
          <div class="col-sm-9">
            <input type="text" name="nama_mitra" class="form-control <?php $__errorArgs = ['nama_mitra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Isi Nama Lembaga Mitra"
            value="<?php echo e(isset($item->id) ? $item->nama_mitra : old('nama_mitra')); ?>" autofocus>
            <?php $__errorArgs = ['nama_mitra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Tingkat</label>
          <div class="col-sm-9 row">
            <div class="col">
              <div class="form-check">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input <?php $__errorArgs = ['tingkat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tingkat"
                  <?php if(isset($item->id) && $item->tingkat == "Internasional"): ?> checked <?php endif; ?>
                  value="Internasional">Internasional<i class="input-helper"></i>
                </label>
              </div>
            </div>
            <div class="col">
              <div class="form-check">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input <?php $__errorArgs = ['tingkat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tingkat"
                  <?php if(isset($item->id) && $item->tingkat == "Nasional"): ?> checked <?php endif; ?>
                  value="Nasional">Nasional<i class="input-helper"></i>
                </label>
              </div>
            </div>
            <div class="col">
              <div class="form-check">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input <?php $__errorArgs = ['tingkat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tingkat"
                  <?php if(isset($item->id) && $item->tingkat == "Lokal"): ?> checked <?php endif; ?>
                  value="Lokal">Lokal<i class="input-helper"></i>
                </label>
              </div>
            </div>
          </div>
          <?php $__errorArgs = ['tingkat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Judul dan Ruang Lingkup Kerjasama</label>
          <div class="col-sm-9">
            <input type="text" name="judul_ruang_lingkup" class="form-control <?php $__errorArgs = ['judul_ruang_lingkup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(isset($item->id) ? $item->judul_ruang_lingkup : old('judul_ruang_lingkup')); ?>" placeholder="Isi Judul dan Ruang Lingkup Kerjasama">
            <?php $__errorArgs = ['judul_ruang_lingkup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Manfaat/Output</label>
          <div class="col-sm-9">
            <input type="text" name="manfaat_output" class="form-control <?php $__errorArgs = ['manfaat_output'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(isset($item->id) ? $item->manfaat_output : old('manfaat_output')); ?>" placeholder="Isi Manfaat/Output">
            <?php $__errorArgs = ['manfaat_output'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Durasi</label>
          <div class="col-sm-9">
            <input type="number" name="durasi" class="form-control <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($item->id) ? $item->durasi : old('durasi')); ?>" placeholder="Isi Durasi">
            <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Bukti/Tautan</label>
          <div class="col-sm-9">
            <input type="url" name="tautan" class="form-control <?php $__errorArgs = ['tautan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($item->id) ? $item->tautan : old('tautan')); ?>" placeholder="Isi Bukti/Tautan">
            <?php $__errorArgs = ['tautan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

      </div>
      <div class="card-footer">
       <?php if(Request::segment(3) === 'create'): ?>
       <button type="submit" class="btn btn-primary mr-2" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';"> Tambah data <?php echo e($bidang); ?> </button>
       <?php elseif(Request::segment(4) === 'edit'): ?>
       <button type="submit" class="btn btn-primary mr-2" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';"> Update data <?php echo e($bidang); ?>  </button>
       <?php endif; ?>
     </div>
   </form>
 </div>
</div>
<!-- last row starts here -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c2/form.blade.php ENDPATH**/ ?>