<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="/kriteria5/penggunaan_dana">
        <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
      </a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.5 Keuangan, Sarana, dan Prasarana</p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <form class="card forms-sample" action="<?php echo e(isset($item->id) ?  route('penggunaan_dana.update', ['id' => Crypt::encryptString($item->id)])  : route('penggunaan_dana.store')); ?>" method="post">
        <?php if(isset($item->id)): ?>
          <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
          <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>

            Penggunaan Dana
          </h4>

          <p class="card-description">K.5 Investsi sarana pendidikan</p>
            <?php if($errors->any()): ?>
              <div>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li style="color: red;"><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
          <hr>

          <div class="form-group row">
  <label class="col-sm-3 col-form-label">Jenis Penggunaan</label>
  <div class="col-sm-9">
    <select class="form-control <?php $__errorArgs = ['jenis_penggunaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jenis_penggunaan">
      <option value="">Pilih</option>
      <option value="Biaya operasional pendidikan" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == "Biaya operasional pendidikan"): ?> selected <?php endif; ?>>
        Biaya operasional pendidikan</option>
      <option value="Biaya kegiatan penelitian" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == ""): ?> selected <?php endif; ?>>
        Biaya kegiatan penelitian</option>
      <option value="Biaya kegiatan pengabdian kepada masyarakat" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == "Biaya kegiatan pengabdian kepada masyarakat"): ?> selected <?php endif; ?>>
        Biaya kegiatan pengabdian kepada masyarakat</option>
      <option value="Biaya kegiatan publikasi" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == "Biaya kegiatan publikasi"): ?> selected <?php endif; ?>>
        Biaya kegiatan publikasi</option>
      <option value="Biaya kegiatan kemahasiswaan" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == "Biaya kegiatan kemahasiswaan"): ?> selected <?php endif; ?>>
        Biaya kegiatan kemahasiswaan</option>
      <option value="Biaya investasi sumber daya manusia (SDM)" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == "Biaya investasi sumber daya manusia (SDM)"): ?> selected <?php endif; ?>>
        Biaya investasi sumber daya manusia (SDM)</option>
      <option value="Investasi prasarana pendidikan" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == "Investasi prasarana pendidikan"): ?> selected <?php endif; ?>>
        Investasi prasarana pendidikan</option>
      <option value="Investasi sarana pendidikan" 
        <?php if(old('jenis_penggunaan', isset($item->jenis_penggunaan) ? $item->jenis_penggunaan : '') == "Investasi sarana pendidikan"): ?> selected <?php endif; ?>>
        Investasi sarana pendidikan</option>
    </select>
    <?php $__errorArgs = ['jenis_penggunaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">TS-2 (<?php echo e(date('Y') - 2); ?>)</label>
  <div class="col-sm-9">
    <input type="text" name="jumlah_ts2" value="<?php echo e(isset($item->jumlah_ts2) ? $item->jumlah_ts2 : old('jumlah_ts2')); ?>" id="nilai2" class="form-control <?php $__errorArgs = ['jumlah_ts2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['jumlah_ts2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">TS-1 (<?php echo e(date('Y') - 1); ?>)</label>
  <div class="col-sm-9">
    <input type="text" name="jumlah_ts1" id="nilai1" value="<?php echo e(isset($item->jumlah_ts1) ? $item->jumlah_ts1 : old('jumlah_ts1')); ?>" class="form-control <?php $__errorArgs = ['jumlah_ts1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['jumlah_ts1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

<div class="form-group row">
  <label class="col-sm-3 col-form-label">TS (<?php echo e(date('Y')); ?>)</label>
  <div class="col-sm-9">
    <input type="text" name="jumlah_ts" id="nilai" value="<?php echo e(isset($item->jumlah_ts) ? $item->jumlah_ts : old('jumlah_ts')); ?>" class="form-control <?php $__errorArgs = ['jumlah_ts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
    <?php $__errorArgs = ['jumlah_ts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>

          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Tautan</label>
            <div class="col-sm-9">
              <input type="text" name="tautan" value="<?php echo e(isset($item->tautan) ? $item->tautan : old('tautan')); ?>" class="form-control" placeholder="Ketik disini">
            </div>
          </div>


          </div>

          <div class="card-footer">
            <button class="btn btn-primary" type="submit" name="button" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';">
              <?php if(Request::segment(3) === 'create'): ?>
              Tambah data
              <?php elseif(Request::segment(4) === 'edit'): ?>
              Update data
              <?php endif; ?>
            </button>
          </div>
        </form>
      </div>
    </div>
    <!-- last row starts here -->

  </div>

  <script>
    document.getElementById('nilai2').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
    document.getElementById('nilai1').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
    document.getElementById('nilai').addEventListener('input', function (e) {
        let value = e.target.value;
        value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        e.target.value = value;
    });
  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c5/penggunaan_dana/form.blade.php ENDPATH**/ ?>