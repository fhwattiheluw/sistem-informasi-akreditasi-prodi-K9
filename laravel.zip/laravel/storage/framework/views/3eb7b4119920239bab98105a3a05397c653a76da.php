<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <a href="<?php echo e(route('publikasi_dtps_dan_mahasiswa.index')); ?>">
        <button class="btn btn-secondary mb-2 mb-md-0 mr-2"> Kembali </button>
      </a>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.9 Publikasi DTPS Dan Mahasiswa</p>
        </a>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col grid-margin stretch-card">
      <form class="card forms-sample" action="<?php echo e(isset($item->id) ?  route('publikasi_dtps_dan_mahasiswa.update', ['id' => $item->id])  : route('publikasi_dtps_dan_mahasiswa.store')); ?>" method="post">
        <?php if(isset($item->id)): ?>
          <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
          <h4 class="card-title">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Edit data
            <?php endif; ?>
            Publikasi DTPS Dan Mahasiswa
          </h4>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>

          <?php if(session('error')): ?>
            <div class="alert alert-danger">
              <?php echo e(session('error')); ?>

            </div>
          <?php endif; ?>

          <hr>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Jenis</label>
            <div class="col-sm-9">
              <select name="jenis" class="form-control <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php if(isset($item->id)): ?> disabled <?php endif; ?>>
                <option value="<?php echo e(old('jenis') ? old('jenis') : ''); ?> "><?php echo e(old('jenis') ? old('jenis') : 'Pilih'); ?> </option>
                <?php $__currentLoopData = $jenis_publikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jenis); ?>" <?php if(isset($item->jenis) && $item->jenis == $jenis): ?> selected <?php endif; ?>><?php echo e($jenis); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Jumlah TS 2</label>
            <div class="col-sm-9">
              <input type="text" name="jumlah_ts_2" value="<?php echo e(isset($item->jumlah_ts_2) ? $item->jumlah_ts_2 : old('jumlah_ts_2')); ?>" class="form-control <?php $__errorArgs = ['jumlah_ts_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
              <?php $__errorArgs = ['jumlah_ts_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Jumlah TS 1</label>
            <div class="col-sm-9">
              <input type="text" name="jumlah_ts_1" value="<?php echo e(isset($item->jumlah_ts_1) ? $item->jumlah_ts_1 : old('jumlah_ts_1')); ?>" class="form-control <?php $__errorArgs = ['jumlah_ts_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
              <?php $__errorArgs = ['jumlah_ts_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Jumlah TS</label>
            <div class="col-sm-9">
              <input type="text" name="jumlah_ts" value="<?php echo e(isset($item->jumlah_ts) ? $item->jumlah_ts : old('jumlah_ts')); ?>" class="form-control <?php $__errorArgs = ['jumlah_ts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketik disini">
              <?php $__errorArgs = ['jumlah_ts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Tautan</label>
            <div class="col-sm-9">
              <input type="text" name="tautan" value="<?php echo e(isset($item->tautan) ? $item->tautan : old('tautan')); ?>" class="form-control" placeholder="Ketik disini">
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary" type="submit" name="button" onclick="this.disabled=true;this.form.submit();this.innerText='Loading...';">
            <?php if(Request::segment(3) === 'create'): ?>
            Tambah data
            <?php elseif(Request::segment(4) === 'edit'): ?>
            Update data
            <?php endif; ?>
          </button>
        </div>
      </form>
    </div>
  </div>
  <script>
    const formatInput = (input) => {
      let value = input.value;
      value = value.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      input.value = value;
    };

    const inputs = document.querySelectorAll('input[type="text"]');
    inputs.forEach(input => {
      input.addEventListener('input', () => {
        formatInput(input);
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c9/publikasi_dtps_dan_mahasiswa/form.blade.php ENDPATH**/ ?>