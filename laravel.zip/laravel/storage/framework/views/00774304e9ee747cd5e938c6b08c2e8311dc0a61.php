<?php $__env->startSection('css'); ?>
  <style>

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-wrapper'); ?>
<div class="content-wrapper pb-0">
  <div class="page-header flex-wrap">
    <div class="header-left">
      <?php if(Auth::user()->role == 'admin prodi'): ?>
      <a href="<?php echo e(route('masa_studi_kelulusan_tepat_waktu_dan_keberhasilan_studi.create')); ?>">
        <button class="btn btn-outline-primary mb-2 mb-md-0 mr-2"> Tambah data </button>
      </a>
      <?php endif; ?>
    </div>
    <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
      <div class="d-flex align-items-center">
        <a href="#">
          <p class="m-0 pr-3">Data Kuantitatif LED</p>
        </a>
        <a class="pl-3 mr-4" href="#">
          <p class="m-0">K.9 Masa Studi, Kelulusan Tepat Waktu, dan Keberhasilan </p>
        </a>
      </div>

    </div>
  </div>
  <!-- first row starts here -->
  <div class="row">
    <div class="col grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Tabel Masa Studi, Kelulusan Tepat Waktu, dan Keberhasilan </h5>
          <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
          <?php endif; ?>
          <?php if(session('info')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <?php echo e(session('info')); ?> Silakan <a href="/dashboard">klik disini.</a>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <?php endif; ?>
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
              <thead class="text-center">
                <tr>
                  <th rowspan="2">Tahun masuk</th>
                  <th rowspan="2">Jumlah Mahasiswa Diterima</th>
                  <th colspan="7">Jumlah Mahasiswa yang Lulus pada … </th>
                  <th rowspan="2">Jumlah Lulusan sd Akhir TS</th>
                  <th rowspan="2">Rata-Rata Masa Studi</th>
                  <th rowspan="2">Tautan</th>
                  <th rowspan="2">Aksi</th>
                </tr>
                <tr>
                  <th>Akhir TS-6</th>
                  <th>Akhir TS-5</th>
                  <th>Akhir TS-4</th>
                  <th>Akhir TS-3</th>
                  <th>Akhir TS-2</th>
                  <th>Akhir TS-1</th>
                  <th>Akhir TS</th>
                </tr>
              </thead>

              <tbody style="overflow-y: auto;" class="text-center" >

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $total = $item->jumlah_lulus_ts_6 + $item->jumlah_lulus_ts_5 + $item->jumlah_lulus_ts_4 + $item->jumlah_lulus_ts_3 + $item->jumlah_lulus_ts_2 + $item->jumlah_lulus_ts_1 + $item->jumlah_lulus_ts;
                $avg = $total / 7;
                ?>
                <tr>
                  <td><?php echo e($item->tahun_masuk); ?></td>
                  <td><?php echo e($item->jumlah_diterima); ?></td>
                  <td><?php echo e($item->jumlah_lulus_ts_6); ?></td>
                  <td><?php echo e($item->jumlah_lulus_ts_5); ?></td>
                  <td><?php echo e($item->jumlah_lulus_ts_4); ?></td>
                  <td><?php echo e($item->jumlah_lulus_ts_3); ?></td>
                  <td><?php echo e($item->jumlah_lulus_ts_2); ?></td>
                  <td><?php echo e($item->jumlah_lulus_ts_1); ?></td>
                  <td><?php echo e($item->jumlah_lulus_ts); ?></td>
                  <td><?php echo e($total); ?></td>
                  <td><?php echo e($avg); ?></td>
                  <td><?php echo $item->tautan ? '<a href="' . $item->tautan . '" target="_blank">Link</a>' : 'Tidak ada tautan'; ?></td>
                  <td>
                    <?php if(Auth::user()->role == 'admin prodi'): ?>

                    <a href="<?php echo e(route('masa_studi_kelulusan_tepat_waktu_dan_keberhasilan_studi.edit', ['id' => $item->id])); ?>" type="button"  class="btn btn-outline-primary btn-sm"><i class="mdi mdi-table-edit" ></i></a>
                    <form action="<?php echo e(route('masa_studi_kelulusan_tepat_waktu_dan_keberhasilan_studi.destroy', ['id' => $item->id])); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-danger btn-sm"><i class="mdi mdi-delete icon" ></i> </button>
                    </form>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>



            </table>
          </div>

        </div>
      </div>
    </div>
  </div>
  <!-- last row starts here -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadli/Documents/Projek GIT/sistem-informasi-akreditasi-prodi-K9/laravel/resources/views/kriteria/c9/masa_studi_kelulusan_tepat_waktu_dan_keberhasilan_studi/index.blade.php ENDPATH**/ ?>