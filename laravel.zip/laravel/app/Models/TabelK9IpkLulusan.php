<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TabelK9IpkLulusan extends Model
{
    use HasFactory;

    protected $table = 'tabel_k9_ipk_lulusans';

    protected $guarded = ['id'];

    protected $fillable = [];
}
