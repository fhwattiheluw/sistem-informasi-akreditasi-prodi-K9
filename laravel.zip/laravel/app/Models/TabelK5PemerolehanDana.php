<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TabelK5PemerolehanDana extends Model
{
    use HasFactory;

    protected $table = 'tabel_k5_pemerolehan_danas';
    protected $guarded = ['id'];
}
